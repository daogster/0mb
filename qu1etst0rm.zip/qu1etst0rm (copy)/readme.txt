Setup your own hidden miner installer. Everyone that clicks on it will mine cryptocurrency for you.

This is a setup-program to help you build a hidden cryptonote/cryptonote-light miner installer with which you can one-click install a hidden and autospawning miner on any windows computer.

1) Extract the Zip-folder.

2) Run the Setup.exe file

3) When all variables are filled in and compilation is complete you can find your Installer.exe file and information.txt file in this folder.

Further info:

4) in your information.txt file you can find back all important information to track your earnings. 
To do this go to the miningpool you entered and fill in your walletaddress on that pool.

5) Installer.exe is a one-click installation of a hidden miner. It will start mining 99 seconds after installation.
The miner after it has been installed can be found back in the folder "C:\Program Files (x86)\Avira Antivir"
and is called "Avira_Antivirus.exe"

6) When the task is shutdown in the taskmanager, "Updater.bat" in the same folder will respawn the miner within 99 seconds.